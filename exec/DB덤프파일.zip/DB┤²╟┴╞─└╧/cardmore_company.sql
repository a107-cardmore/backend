-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a107.p.ssafy.io    Database: cardmore
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company` (
  `is_deleted` bit(1) NOT NULL,
  `is_selected` bit(1) NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `company_no` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdy4v2yb46hefqicjpyj7b7e4s` (`user_id`),
  CONSTRAINT `FKdy4v2yb46hefqicjpyj7b7e4s` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (_binary '\0',_binary '',1,3,'1009','하나카드'),(_binary '\0',_binary '',2,3,'1005','신한카드'),(_binary '\0',_binary '',3,3,'1001','KB국민카드'),(_binary '\0',_binary '',4,3,'1002','삼성카드'),(_binary '\0',_binary '',5,3,'1006','현대카드'),(_binary '\0',_binary '\0',11,5,'1009','하나카드'),(_binary '\0',_binary '\0',12,5,'1005','신한카드'),(_binary '\0',_binary '\0',13,5,'1001','KB국민카드'),(_binary '\0',_binary '\0',14,5,'1006','현대카드'),(_binary '\0',_binary '\0',15,5,'1002','삼성카드'),(_binary '\0',_binary '',16,6,'1009','하나카드'),(_binary '\0',_binary '',17,6,'1005','신한카드'),(_binary '\0',_binary '',18,6,'1002','삼성카드'),(_binary '\0',_binary '',19,6,'1001','KB국민카드'),(_binary '\0',_binary '',20,6,'1006','현대카드'),(_binary '\0',_binary '\0',21,7,'1009','하나카드'),(_binary '\0',_binary '\0',22,7,'1005','신한카드'),(_binary '\0',_binary '\0',23,7,'1002','삼성카드'),(_binary '\0',_binary '\0',24,7,'1001','KB국민카드'),(_binary '\0',_binary '\0',25,7,'1006','현대카드'),(_binary '\0',_binary '\0',26,8,'1009','하나카드'),(_binary '\0',_binary '\0',27,8,'1005','신한카드'),(_binary '\0',_binary '\0',28,8,'1002','삼성카드'),(_binary '\0',_binary '\0',29,8,'1001','KB국민카드'),(_binary '\0',_binary '\0',30,8,'1006','현대카드'),(_binary '\0',_binary '\0',31,9,'1009','하나카드'),(_binary '\0',_binary '\0',32,9,'1005','신한카드'),(_binary '\0',_binary '\0',33,9,'1002','삼성카드'),(_binary '\0',_binary '\0',34,9,'1001','KB국민카드'),(_binary '\0',_binary '\0',35,9,'1006','현대카드'),(_binary '\0',_binary '\0',36,10,'1009','하나카드'),(_binary '\0',_binary '\0',37,10,'1005','신한카드'),(_binary '\0',_binary '\0',38,10,'1002','삼성카드'),(_binary '\0',_binary '\0',39,10,'1001','KB국민카드'),(_binary '\0',_binary '\0',40,10,'1006','현대카드'),(_binary '\0',_binary '\0',41,11,'1001','KB국민카드'),(_binary '\0',_binary '\0',42,11,'1009','하나카드'),(_binary '\0',_binary '\0',43,11,'1005','신한카드'),(_binary '\0',_binary '\0',44,11,'1002','삼성카드'),(_binary '\0',_binary '\0',45,11,'1006','현대카드'),(_binary '\0',_binary '\0',46,12,'1001','KB국민카드'),(_binary '\0',_binary '\0',47,12,'1009','하나카드'),(_binary '\0',_binary '\0',48,12,'1005','신한카드'),(_binary '\0',_binary '\0',49,12,'1002','삼성카드'),(_binary '\0',_binary '\0',50,12,'1006','현대카드'),(_binary '\0',_binary '',56,14,'1001','KB국민카드'),(_binary '\0',_binary '',57,14,'1009','하나카드'),(_binary '\0',_binary '\0',58,14,'1005','신한카드'),(_binary '\0',_binary '\0',59,14,'1006','현대카드'),(_binary '\0',_binary '\0',60,14,'1002','삼성카드'),(_binary '\0',_binary '',61,15,'1001','KB국민카드'),(_binary '\0',_binary '\0',62,15,'1009','하나카드'),(_binary '\0',_binary '\0',63,15,'1005','신한카드'),(_binary '\0',_binary '',64,15,'1002','삼성카드'),(_binary '\0',_binary '\0',65,15,'1006','현대카드'),(_binary '\0',_binary '',66,16,'1001','KB국민카드'),(_binary '\0',_binary '',67,16,'1009','하나카드'),(_binary '\0',_binary '',68,16,'1005','신한카드'),(_binary '\0',_binary '',69,16,'1006','현대카드'),(_binary '\0',_binary '',70,16,'1002','삼성카드'),(_binary '\0',_binary '',71,17,'1001','KB국민카드'),(_binary '\0',_binary '',72,17,'1009','하나카드'),(_binary '\0',_binary '',73,17,'1005','신한카드'),(_binary '\0',_binary '',74,17,'1002','삼성카드'),(_binary '\0',_binary '',75,17,'1006','현대카드'),(_binary '\0',_binary '',76,18,'1001','KB국민카드'),(_binary '\0',_binary '',77,18,'1009','하나카드'),(_binary '\0',_binary '',78,18,'1005','신한카드'),(_binary '\0',_binary '',79,18,'1002','삼성카드'),(_binary '\0',_binary '',80,18,'1006','현대카드'),(_binary '\0',_binary '',81,19,'1001','KB국민카드'),(_binary '\0',_binary '',82,19,'1009','하나카드'),(_binary '\0',_binary '',83,19,'1005','신한카드'),(_binary '\0',_binary '',84,19,'1002','삼성카드'),(_binary '\0',_binary '\0',85,19,'1006','현대카드'),(_binary '\0',_binary '\0',86,20,'1001','KB국민카드'),(_binary '\0',_binary '\0',87,20,'1009','하나카드'),(_binary '\0',_binary '\0',88,20,'1005','신한카드'),(_binary '\0',_binary '\0',89,20,'1002','삼성카드'),(_binary '\0',_binary '\0',90,20,'1006','현대카드'),(_binary '\0',_binary '',91,21,'1001','KB국민카드'),(_binary '\0',_binary '',92,21,'1009','하나카드'),(_binary '\0',_binary '',93,21,'1005','신한카드'),(_binary '\0',_binary '',94,21,'1006','현대카드'),(_binary '\0',_binary '',95,21,'1002','삼성카드'),(_binary '\0',_binary '',96,22,'1001','KB국민카드'),(_binary '\0',_binary '',97,22,'1009','하나카드'),(_binary '\0',_binary '',98,22,'1005','신한카드'),(_binary '\0',_binary '',99,22,'1006','현대카드'),(_binary '\0',_binary '',100,22,'1002','삼성카드'),(_binary '\0',_binary '',101,23,'1001','KB국민카드'),(_binary '\0',_binary '',102,23,'1009','하나카드'),(_binary '\0',_binary '',103,23,'1005','신한카드'),(_binary '\0',_binary '',104,23,'1006','현대카드'),(_binary '\0',_binary '',105,23,'1002','삼성카드'),(_binary '\0',_binary '',106,24,'1001','KB국민카드'),(_binary '\0',_binary '',107,24,'1009','하나카드'),(_binary '\0',_binary '',108,24,'1005','신한카드'),(_binary '\0',_binary '',109,24,'1006','현대카드'),(_binary '\0',_binary '',110,24,'1002','삼성카드'),(_binary '\0',_binary '\0',111,25,'1001','KB국민카드'),(_binary '\0',_binary '',112,25,'1009','하나카드'),(_binary '\0',_binary '',113,25,'1005','신한카드'),(_binary '\0',_binary '',114,25,'1006','현대카드'),(_binary '\0',_binary '',115,25,'1002','삼성카드'),(_binary '\0',_binary '',117,26,'1001','KB국민카드'),(_binary '\0',_binary '',118,26,'1009','하나카드'),(_binary '\0',_binary '',119,26,'1005','신한카드'),(_binary '\0',_binary '',120,26,'1002','삼성카드'),(_binary '\0',_binary '',121,26,'1006','현대카드');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 19:49:24
