-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a107.p.ssafy.io    Database: cardmore
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `is_deleted` bit(1) NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `user_key` varchar(100) NOT NULL,
  `account_no` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES (_binary '\0',1,'a107test1@naver.com','4b4293c7-7b6f-40fb-8841-4108622b6fda','0016482741961329'),(_binary '\0',2,'a107test2002@naver.com','ac02dbdf-5679-4a1c-beb8-d632a12bba27','0010002902143218'),(_binary '\0',3,'a107test1000@naver.com','e87c5918-b274-433c-90d1-f87b540fb6d1','0010529361391676'),(_binary '\0',4,'a107test2005@naver.com','a80cb84d-7c13-44f5-83fb-488fd74cc561','0012557679582555'),(_binary '\0',5,'a107test3@naver.com','7c1dc18d-67f0-497f-923a-91799265b524','0011785860208699'),(_binary '\0',6,'a107test4@naver.com','419b6605-4d0d-4787-b130-a6611cd7bf55','0017685795533361'),(_binary '\0',7,'a107test5@naver.com','e18c62b4-494b-4d40-8c86-86b2e211165b','0018292955378222'),(_binary '\0',8,'a107test6@naver.com','a024c8b6-9d25-4dc8-971a-85ebc681a4e3','0011958067584448'),(_binary '\0',9,'a107test2010@naver.com','47fd2bdd-1ab1-4be6-9499-93a028d929c8','0010959176720831'),(_binary '\0',10,'a107test2011@naver.com','eb7bef57-748e-4273-a344-38a189cc4c65','0011500592567874'),(_binary '\0',12,'a107test2013@naver.com','e8cf40de-5347-4f86-a31f-9065a746fd38','0017434327559457'),(_binary '\0',13,'a107test2006@naver.com','71424b31-3a0b-4ff8-8d2d-cf8dce2574b4','0017917769277835'),(_binary '\0',14,'a107test10@naver.com','7ca2ffd4-425c-4ee2-ab2d-c83030a7135e','0010893921891143'),(_binary '\0',15,'a107test0101@naver.com','55769c09-fbb8-4b34-8993-22717d75a916','0014344494371273'),(_binary '\0',16,'a107test0102@naver.com','dcc45ead-b37c-429c-86ad-4ecc6e60b39e','0018786564048693'),(_binary '\0',17,'a107test11@naver.com','40e89552-ab36-468e-854b-ae878cae3e08','0012641496726265'),(_binary '\0',18,'a107test111111111111@naver.com','33188b3d-4964-4fea-890d-a9e737a456d4','0016665463211311'),(_binary '\0',19,'a107test123@naver.com','1179a3a0-5d89-4742-8b59-365f47e6fe79','0011362774786803'),(_binary '\0',20,'a107@naver.com','76a113af-050e-47c4-adff-3782ebabef77','0018594042707414'),(_binary '\0',21,'a107test107@naver.com','5972836b-ffe8-4465-9a23-b03f3a6d03b8','0018151656618007'),(_binary '\0',22,'a107test1004@naver.com','f42255d8-9cde-4c4c-b667-9105b9acd4df','0014178293539865'),(_binary '\0',23,'a107test117@naver.com','8b865e9f-3de6-40ba-be8d-acf2e8eea9e9','0011537645190902'),(_binary '\0',24,'a107test12@naver.com','70bb97e0-b1d3-4ebd-963f-af3ac5b98c8f','0014070089661333');
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 19:49:22
