-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a107.p.ssafy.io    Database: cardmore
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `is_deleted` bit(1) NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role` varchar(10) NOT NULL,
  `account_no` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `nick_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_key` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (_binary '\0',3,'USER','0016482741961329','a107test1@naver.com','test','lucy','$2a$10$B3JBaFlq7O3ZD76F6g2jX.WPouQglu/wXiejPRmibflUhDZlDJiXS','4b4293c7-7b6f-40fb-8841-4108622b6fda'),(_binary '\0',5,'USER','0010529361391676','a107test1000@naver.com','dongyul test','열동','$2a$10$07wHeypzKp1s2LJUGgmwNeJ3hNo.4aTlzg1qDU7/ysqvGku0w/Wb2','e87c5918-b274-433c-90d1-f87b540fb6d1'),(_binary '\0',6,'USER','0012557679582555','a107test2005@naver.com','test','상짱욱','$2a$10$h9KSpSUYEoYM4LQgJBWy8e4bIns3zkm0t4TaAW4/0cZGDUxygnECO','a80cb84d-7c13-44f5-83fb-488fd74cc561'),(_binary '\0',7,'USER','0011785860208699','a107test3@naver.com','a107test3','a107test3','$2a$10$FQYCiL1Vp8WTzb0SFxFYjuKPHLhpD53woyoO7Sf5egnZVRax28K0W','7c1dc18d-67f0-497f-923a-91799265b524'),(_binary '\0',8,'USER','0017685795533361','a107test4@naver.com','a107test4','a107test4','$2a$10$lvyF99MZ8.NCc3mM0SPJe.zpDoZxbKQLmQLN5U8gTVIUOZjmHqbZO','419b6605-4d0d-4787-b130-a6611cd7bf55'),(_binary '\0',9,'USER','0018292955378222','a107test5@naver.com','a107test5','a107test5','$2a$10$NPF7s.A9KDLR87sHkBjJa.lsRwXqhh0.mFICNdKDXvhLuBr/CxRVC','e18c62b4-494b-4d40-8c86-86b2e211165b'),(_binary '\0',10,'USER','0011958067584448','a107test6@naver.com','a107test6','a107test6','$2a$10$m1xDBClNlplmAQOgTOxfnui1YwoCYto2HjzEnyDwxcue4PhNpYe8S','a024c8b6-9d25-4dc8-971a-85ebc681a4e3'),(_binary '\0',11,'USER','0010959176720831','a107test2010@naver.com','박상욱','박상욱','$2a$10$yIxUI8hefQsqOwKoWxx35e4W3yJPaFUnlpygM2qE0qpUSCho0ZhQe','47fd2bdd-1ab1-4be6-9499-93a028d929c8'),(_binary '\0',12,'USER','0011500592567874','a107test2011@naver.com','박상욱','박상욱','$2a$10$6rfCgMeXPRV9udiP0o2mCeFBE2s4dCILoMzJVF19KVbWIJ8ShABuK','eb7bef57-748e-4273-a344-38a189cc4c65'),(_binary '\0',14,'USER','0017434327559457','a107test2013@naver.com','박상욱','박상욱','$2a$10$jnjWJSP9TlXSZLATlLuYDuHOzSRWryn2YIp7cFfxS37gE0OlIkede','e8cf40de-5347-4f86-a31f-9065a746fd38'),(_binary '\0',15,'USER','0017917769277835','a107test2006@naver.com','김싸피','김싸피','$2a$10$ZOnTnF1j.eRexWPDbQV/B.3OE4gmwRC3sTnu2hYm9FGbOmwJFT/52','71424b31-3a0b-4ff8-8d2d-cf8dce2574b4'),(_binary '\0',16,'USER','0010893921891143','a107test10@naver.com','지수영','SooYoung','$2a$10$wkrjVQwMQgWO/r5njz3VXuGkqPSpBbY9peB0fSoqP3oD7sUtUhaE6','7ca2ffd4-425c-4ee2-ab2d-c83030a7135e'),(_binary '\0',17,'USER','0014344494371273','a107test0101@naver.com','발표 테스트','SooYoung','$2a$10$OJa2ajKwmT5B9P4v7DW52.OvKotwhiQjf2gSKSjlzx8LNYrS5fUFy','55769c09-fbb8-4b34-8993-22717d75a916'),(_binary '\0',18,'USER','0018786564048693','a107test0102@naver.com','테스트0102','테스트0102','$2a$10$e7Hfj2JOcSgcyYPIVracyuxELM8N.WgsjcJH2Rrzz.aPrzVpAhzjK','dcc45ead-b37c-429c-86ad-4ecc6e60b39e'),(_binary '\0',19,'USER','0012641496726265','a107test11@naver.com','김사비','SSAFY','$2a$10$IshNSISi/cpKKkRokzDoKugGObbUL6Oq0eQoTw4qHMY.1YhbTgOlO','40e89552-ab36-468e-854b-ae878cae3e08'),(_binary '\0',20,'USER','0016665463211311','a107test111111111111@naver.com','123','123','$2a$10$sciTKygdIaYdydczv0mfZOwgnrt0M0K/1.BvjCokwS1LF5g11QLf2','33188b3d-4964-4fea-890d-a9e737a456d4'),(_binary '\0',21,'USER','0011362774786803','a107test123@naver.com','지수영','SooYoung','$2a$10$5MauXSeNwPkdNd8A4RzaC.VxsIVB4athnGBl1nwMzNnnxLalrSrZS','1179a3a0-5d89-4742-8b59-365f47e6fe79'),(_binary '\0',22,'USER','0018594042707414','a107@naver.com','지수영','SooYoung','$2a$10$uBpENzTPjI4Arg5hnJVEluDv9mtOC3yQcM9hfK8G8d6GNyCycRzwS','76a113af-050e-47c4-adff-3782ebabef77'),(_binary '\0',23,'USER','0018151656618007','a107test107@naver.com','지수영','Jenny','$2a$10$WtfDcFBU.KoGkuUQDbYtPOuz3wH1H7gRWsTs9vdgOYumnq7M8qraG','5972836b-ffe8-4465-9a23-b03f3a6d03b8'),(_binary '\0',24,'USER','0014178293539865','a107test1004@naver.com','dongyul','열동','$2a$10$y2H/yR2HkikVfkOaJjnGjOpfY3gaCJ2HMqhIbynrZVjrGSqVR32ku','f42255d8-9cde-4c4c-b667-9105b9acd4df'),(_binary '\0',25,'USER','0011537645190902','a107test117@naver.com','지수영','Jennifer','$2a$10$RvsaMF7LGdD5WpYGHK5m7uDjRUGoAu3K206oxLPduMpNQ2Gef1sde','8b865e9f-3de6-40ba-be8d-acf2e8eea9e9'),(_binary '\0',26,'USER','0014070089661333','a107test12@naver.com','테스트12','SAFFY123','$2a$10$0SpKcixpUwuIMso5G2Y0IummZx84LwMvUL06BTKO2/o5qjPYbuvOm','70bb97e0-b1d3-4ebd-963f-af3ac5b98c8f');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 19:49:23
